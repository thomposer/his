<?php
    
namespace app\common\base;
use yii\db\ActiveRecord;
use Yii;

    class BaseActiveRecord extends ActiveRecord{
        
        
    }