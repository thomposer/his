<?php

return [
    'class' => 'yii\db\Connection',
    'dsn' => 'mysql:host=localhost;dbname=gzhoss',
    'username' => 'root',
    'password' => '123456',
    'charset' => 'utf8',
    'tablePrefix'=>'gzh_',
    'queryCacheDuration' => 30,
    'queryCache' => 'cache',
    'enableQueryCache' => true
];
