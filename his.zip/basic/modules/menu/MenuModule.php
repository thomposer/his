<?php

namespace app\modules\menu;

class MenuModule extends \yii\base\Module
{
    public $controllerNamespace = 'app\modules\menu\controllers';

    public function init()
    {
        parent::init();

        // custom initialization code goes here
    }
}
